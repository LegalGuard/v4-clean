// Fonction Netlify pour traiter les paiements Stripe
// Compatible avec Stripe v11 et Node.js 16
const stripe = require('stripe')(process.env.STRIPE_SECRET_KEY, {
  apiVersion: '2022-11-15' // Version API compatible avec Stripe v11
});

exports.handler = async (event, context) => {
  if (event.httpMethod !== 'POST') {
    return { statusCode: 405, body: JSON.stringify({ error: 'Méthode non autorisée' }) };
  }

  try {
    const data = JSON.parse(event.body);
    const { paymentMethodId, amount, isRecurring, donorInfo } = data;

    console.log(`Traitement de paiement: ${isRecurring ? 'récurrent' : 'ponctuel'} de ${amount} €`);
    
    // Créer ou récupérer un client
    let customer;
    const existingCustomers = await stripe.customers.list({
      email: donorInfo.email,
      limit: 1
    });
    
    if (existingCustomers.data.length > 0) {
      customer = existingCustomers.data[0];
      console.log(`Client existant trouvé: ${customer.id}`);
    } else {
      customer = await stripe.customers.create({
        email: donorInfo.email,
        name: `${donorInfo.firstName} ${donorInfo.lastName}`,
        payment_method: paymentMethodId,
        invoice_settings: {
          default_payment_method: paymentMethodId,
        },
      });
      console.log(`Nouveau client créé: ${customer.id}`);
    }

    // Attacher la méthode de paiement au client
    await stripe.paymentMethods.attach(paymentMethodId, {
      customer: customer.id,
    });

    if (isRecurring) {
      // Créer un abonnement mensuel pour les dons récurrents
      const lookupKey = `monthly_${amount}`;
      
      // Rechercher le produit et le prix par lookupKey
      const prices = await stripe.prices.list({
        lookup_keys: [lookupKey],
        expand: ['data.product']
      });
      
      let priceId;
      
      if (prices.data.length > 0) {
        // Utiliser le prix existant
        priceId = prices.data[0].id;
        console.log(`Prix existant trouvé: ${priceId}`);
      } else {
        // Créer un nouveau produit et un prix
        const product = await stripe.products.create({
          name: `Don mensuel de ${amount}€`,
          description: `Don mensuel récurrent de ${amount}€ à GivPlus`
        });
        
        const price = await stripe.prices.create({
          product: product.id,
          unit_amount: amount * 100, // en centimes
          currency: 'eur',
          recurring: {
            interval: 'month'
          },
          lookup_key: lookupKey
        });
        
        priceId = price.id;
        console.log(`Nouveau prix créé: ${priceId}`);
      }
      
      // Créer l'abonnement
      const subscription = await stripe.subscriptions.create({
        customer: customer.id,
        items: [{ price: priceId }],
        payment_behavior: 'default_incomplete',
        payment_settings: { save_default_payment_method: 'on_subscription' },
        expand: ['latest_invoice.payment_intent'],
      });
      
      // Confirmer le paiement
      const paymentIntent = subscription.latest_invoice.payment_intent;
      
      if (paymentIntent.status === 'requires_payment_method') {
        await stripe.paymentIntents.confirm(paymentIntent.id, {
          payment_method: paymentMethodId
        });
      }
      
      return {
        statusCode: 200,
        body: JSON.stringify({
          id: subscription.id,
          client_secret: paymentIntent.client_secret
        })
      };
    } else {
      // Créer un paiement ponctuel
      const paymentIntent = await stripe.paymentIntents.create({
        amount: amount * 100, // en centimes
        currency: 'eur',
        customer: customer.id,
        payment_method: paymentMethodId,
        confirmation_method: 'manual',
        confirm: true,
        description: `Don ponctuel de ${amount}€ à GivPlus`,
        metadata: {
          donorName: `${donorInfo.firstName} ${donorInfo.lastName}`,
          donorEmail: donorInfo.email
        }
      });
      
      return {
        statusCode: 200,
        body: JSON.stringify({
          id: paymentIntent.id,
          client_secret: paymentIntent.client_secret,
          status: paymentIntent.status
        })
      };
    }
  } catch (error) {
    console.error('Erreur de paiement:', error.message);
    return {
      statusCode: 400,
      body: JSON.stringify({ error: error.message })
    };
  }
};
